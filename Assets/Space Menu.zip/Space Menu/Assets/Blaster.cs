﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using System;
using UnityEngine.UI;

public class Blaster : MonoBehaviour, IPointerClickHandler {
    //Here I define my variables, I will need the rocket position and current tilt.  I will also need to know if the charge is good
    int Charge; //This variable will tell me whether or not the charge is sufficient to fire
    float CurrentShipTilt;//This is the current tilt of the ship to use to instantiate the laser
    Vector2 CurrentShipPosition;//this is the current position of the ship to use with the instantiate laser
    public GameObject LaserPrefab;//this is the laser with an attached box collider
    public float ForcePublic;

    public void OnPointerClick(PointerEventData data)
    {
        if (Charge>50)
        {
            Charge = Charge - 50;
            CurrentShipTilt = GameObject.Find("Rocket").transform.eulerAngles.z;//Current Z rotation which is the axis the ship rotates around
            CurrentShipPosition = GameObject.Find("Rocket").transform.position;//Current ship position
            //Below makes a game object on top of the blaster of the ship.  The first variable is ship position, then comes the hypotenuse of the distance
            //from ship center to the blaster for center of ship to center of laser, then we add in a base angle due to the offset to be added to any additional
            //angle from the ship and take the components to determine where to spawn the laser.  KEEPING IN MIND THAT COS AND SIN TAKE RADIANS AND NOT DEGREES.
            //The tilt is applied to the laser to match the ship.  This is all assigned to KickTheLaser which is seen below.      
            GameObject KickTheLaser=Instantiate(LaserPrefab, new Vector2(CurrentShipPosition.x+(1.14236246436934f * Mathf.Cos(CurrentShipTilt*Mathf.Deg2Rad+ 0.18042148f)),
                CurrentShipPosition.y+(1.14236246436934f* Mathf.Sin(CurrentShipTilt*Mathf.Deg2Rad+ 0.18042148f))),Quaternion.Euler(0,0,CurrentShipTilt)) as GameObject;
            //This Takes the prefab and gives the force that is then componetized based on its tilt
            KickTheLaser.GetComponent<Rigidbody2D>().AddForce(new Vector2( ForcePublic * Mathf.Cos(CurrentShipTilt * Mathf.Deg2Rad),
                ForcePublic * Mathf.Sin(CurrentShipTilt * Mathf.Deg2Rad)),ForceMode2D.Impulse);
            KickTheLaser.AddComponent<LaserGovernance>();
        }
    }



    void Update()
    {
        if (Charge < 100)//This is the incremental charge for the blaster, cannot exceed 100
        {
            Charge++;
            if(Charge==100)
            {
                GetComponent<Image>().color = Color.green;
            }
            else if (Charge > 50)
            {
                GetComponent<Image>().color = Color.yellow;
            }
            else
            {
                GetComponent<Image>().color = Color.red;
            }

        }
    }
}
